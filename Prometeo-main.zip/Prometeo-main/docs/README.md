# Documentación de Prometeo

Prometeo es un calculador determinista de Metrología causal.

La arquitectura operativa separa cuatro funciones:

1. **Discriminación humana:** el analista define el fenómeno, los nodos, las relaciones, los soportes y los insumos.
2. **Orientación taxonómica:** la Taxonomía ofrece protocolos, preguntas, rangos y parámetros aplicables al dominio.
3. **Cálculo:** el motor ejecuta los operadores solicitados conforme a sus contratos matemáticos.
4. **Robustez del resultado:** el sistema informa convergencia, sensibilidad, estabilidad del ranking y condiciones de cambio.

La trazabilidad conserva versión del motor, revisión de las fuentes taxonómicas, configuración e insumos utilizados. Los datos operativos de Taxonomía se mantienen en `taxonomia/datos/`; cada elemento conserva `sourceRef` para identificar su procedencia.

El historial de desarrollo permanece disponible en Git y no forma parte de la documentación vigente.
