-- Acceso a Prometeo dentro del proyecto compartido Meriadock Academy.
-- Independiente de las políticas de acceso y datos de Academia.
create table if not exists public.prometeo_access (
  user_id uuid primary key references public.users(id) on delete cascade,
  enabled boolean not null default true,
  granted_at timestamptz not null default now(),
  granted_by uuid references public.users(id) on delete set null
);
alter table public.prometeo_access enable row level security;
revoke all on public.prometeo_access from public, anon, authenticated;
grant select, insert, update, delete on public.prometeo_access to authenticated;
drop policy if exists "prometeo_access_read_self_or_manager" on public.prometeo_access;
create policy "prometeo_access_read_self_or_manager" on public.prometeo_access for select to authenticated
using ((user_id=auth.uid() and private.is_user_active()) or private.has_permission('prometeo.access.manage'));
drop policy if exists "prometeo_access_manage" on public.prometeo_access;
create policy "prometeo_access_manage" on public.prometeo_access for all to authenticated
using (private.has_permission('prometeo.access.manage')) with check (private.has_permission('prometeo.access.manage'));
insert into public.permissions (key,description) values ('prometeo.access.manage','Administrar accesos a Prometeo')
on conflict (key) do update set description=excluded.description;
insert into public.role_permissions (role_id,permission_id)
select r.id,p.id from public.roles r cross join public.permissions p
where r.key='system_admin' and p.key='prometeo.access.manage' on conflict do nothing;
insert into public.prometeo_access (user_id,enabled,granted_by)
select u.id,true,u.id from public.users u
join public.user_roles ur on ur.user_id=u.id join public.roles r on r.id=ur.role_id
where r.key='system_admin' and u.is_active=true and ur.scope_type='global'
on conflict (user_id) do nothing;
