# Prometeo — Calculador de Metrología causal

Prometeo implementa operadores deterministas de **Metrología causal**.

**Humano discrimina e integra → Taxonomía orienta → motor calcula → el expediente muestra el cálculo y su robustez.**

La aplicación se publica en `/tecnologia/Prometeo` con encabezado y pie institucionales de Meriadock. El ingreso usa Supabase Auth del mismo proyecto que Meriadock Academy. Las cuentas y contraseñas son compartidas; el permiso para Prometeo se concede aparte mediante `public.prometeo_access` y sus políticas RLS. No hay registro público. Las APIs validan la sesión y el permiso antes de procesar solicitudes. El texto libre permanece descriptivo: el motor no inventa hechos ni sustituye la discriminación del analista.

## Flujo ordinario

1. Se define la finalidad, el fenómeno y el evento determinado `D`.
2. Se discriminan nodos, relaciones, soportes e insumos conforme al protocolo taxonómico elegido.
3. Se seleccionan las mediciones que se quieren ejecutar.
4. El motor resuelve sus dependencias, calcula y conserva trazabilidad.
5. El resultado informa valores, convergencia, sensibilidad, estabilidad de ranking y condiciones de cambio cuando correspondan.
6. El expediente exporta las mediciones ejecutadas, sus dependencias efectivas, la trazabilidad del cálculo y su robustez.

## Contrato matemático

`POST /tecnologia/Prometeo/api/calcular` recibe `analisis`, `medicionesSolicitadas`, `insumos` y `configuracion`. Cada operador se ejecuta conforme a su contrato matemático y a los insumos declarados que ese contrato requiere.

`D` delimita el fenómeno explicado y permanece fuera de `W_D` y de `R*`. La convención es `W_ij = w(N_i → N_j)` y el operador canónico es el eigenvector derecho de Perron–Frobenius:

`W R* = ρ R*`, con normalización L1.

La regularización, cuando se solicita, conserva separadas la matriz empírica y la matriz regularizada. `ε` no es un peso empírico.

Los demás operadores preservan sus contratos propios: `S`, `α`, `Δ`, `IIC`, `B*`, daño, ajuste debitor, Shapley, opacidad, probabilidad sectorial y los restantes operadores registrados.

## Ejecución y trazabilidad

La Taxonomía aporta preguntas, rangos, componentes y estrategias aplicables al dominio. `sourceRef` identifica la procedencia documental de esos elementos. El motor ejecuta las mediciones registradas, conserva los insumos utilizados y permite reconstruir el cálculo.

## Robustez

La robustez describe **el resultado calculado**: convergencia numérica, sensibilidad, estabilidad del ranking y condiciones explícitas de cambio.

## Salidas

- `/api/expediente` genera el expediente metrológico reproducible.
- `/api/narrativa` genera un resumen determinista.
- `/api/operadores` publica las mediciones ejecutables.
- `/api/protocolos` publica la proyección operativa de los protocolos taxonómicos.

## Verificación

```sh
npm ci
npm test
npm run build
npx playwright install --with-deps chromium
npm run test:ui
```

GitHub Actions ejecuta instalación limpia, pruebas, build y recorrido de interfaz.

## Arquitectura documental

La documentación vigente se concentra en `docs/`. Los archivos de `taxonomia/datos/` contienen únicamente la proyección consumida por el calculador y referencias de procedencia. El historial de implementación permanece en Git.
