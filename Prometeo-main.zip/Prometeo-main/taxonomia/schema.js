'use strict';
function validarFuente(f){
 if(!f||['repositorio','sha','path','capitulo','seccion','reglaId'].some(k=>typeof f[k]!=='string'||!f[k].trim())||! /^[a-f0-9]{40}$/.test(f.sha))throw Error('sourceRef incompleto');
}
function validarDeclarativo(p){
 if(p.schemaVersion!=='taxonomia/1'||!['universal','dominio','operador'].includes(p.capa)||typeof p.id!=='string'||!p.id.trim()||typeof p.version!=='string'||!p.version.trim()||!Array.isArray(p.reglas))throw Error('Schema declarativo inválido');
 validarFuente(p.sourceRef);const ids=new Set();
 for(const r of p.reglas){
  if(!r.id||ids.has(r.id))throw Error('Regla duplicada o sin ID');
  ids.add(r.id);
  if(!r.tipo||!r.texto||!Array.isArray(r.condiciones))throw Error('Regla sin contrato taxonómico');
  validarFuente(r.sourceRef);
 }
 return structuredClone(p);
}
function fusionar(universales,overlay){
 validarDeclarativo(overlay);universales.forEach(validarDeclarativo);
 const refs=universales.map(u=>u.id+'@'+u.version);
 if(JSON.stringify(overlay.hereda)!==JSON.stringify(refs))throw Error('Herencia universal incompleta');
 const ids=new Set();
 for(const p of [...universales,overlay])for(const r of p.reglas){
  if(ids.has(r.id))throw Error('ID duplicado entre capas');
  ids.add(r.id);
 }
 return {...structuredClone(overlay),universales:structuredClone(universales),reglasEfectivas:[...universales.flatMap(u=>u.reglas),...overlay.reglas]};
}
function confirmarSugerencia(regla,eleccion){
 if(eleccion?.confirmado!==true||typeof eleccion.referencia!=='string'||!eleccion.referencia.trim()||!Number.isFinite(eleccion.valor))return {estado:'indeterminado',valor:null,motivo:'Falta confirmación y justificación del analista'};
 const rango=regla?.rango||(Array.isArray(regla?.valor)&&regla.valor.length===2?regla.valor:null);
 if(!rango)return {estado:'indeterminado',valor:null,motivo:'La regla no define un intervalo numérico confirmable'};
 if(eleccion.valor<rango[0]||eleccion.valor>rango[1])return {estado:'error',valor:null,motivo:'Fuera del intervalo sugerido'};
 return {estado:'calculado',valor:eleccion.valor,sourceRef:structuredClone(regla.sourceRef),confirmacion:structuredClone(eleccion)};
}
module.exports={validarFuente,validarDeclarativo,fusionar,confirmarSugerencia};
