# Datos taxonómicos operativos

Este directorio contiene la proyección de Taxonomía que consume Prometeo: protocolos, preguntas, rangos, componentes de S, estrategias de α y referencias de procedencia.

`sourceRef` identifica el repositorio, revisión y sección de origen. La ejecución del calculador depende del contrato del operador y de sus insumos; estos archivos no contienen un inventario de desarrollo.

Las formulaciones doctrinales completas permanecen en sus fuentes de origen. Prometeo conserva aquí sólo la estructura necesaria para orientar la discriminación y ejecutar los cálculos.
