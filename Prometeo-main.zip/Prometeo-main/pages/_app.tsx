import "@/styles/globals.css";
import type { AppProps } from "next/app";
import InstitutionalHeader from "@/components/InstitutionalHeader";
import InstitutionalFooter from "@/components/InstitutionalFooter";
export default function App({Component,pageProps}:AppProps){return <><InstitutionalHeader/><Component {...pageProps}/><InstitutionalFooter/></>;}
