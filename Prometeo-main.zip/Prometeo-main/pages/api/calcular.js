const { requirePrometeoAccess } = require("../../lib/server/requirePrometeoAccess");
const {calcularSolicitud}=require('../../dist-motor/entrada');
export default async function handler(req,res){
 if(!(await requirePrometeoAccess(req,res))) return;
 if(req.method!=='POST')return res.status(405).json({error:'Método no permitido'});
 try{return res.status(200).json(calcularSolicitud(req.body));}
 catch(error){return res.status(400).json({error:error.message});}
}
