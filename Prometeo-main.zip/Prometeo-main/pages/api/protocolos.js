const { requirePrometeoAccess } = require("../../lib/server/requirePrometeoAccess");
const {listarProtocolosPublicos}=require('../../taxonomia/protocolos');
export default async function handler(req,res){
 if(!(await requirePrometeoAccess(req,res))) return;if(req.method!=='GET')return res.status(405).json({error:'Método no permitido'});return res.status(200).json({protocolos:listarProtocolosPublicos()});
}
