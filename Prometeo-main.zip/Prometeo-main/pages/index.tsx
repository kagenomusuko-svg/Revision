import PrometeoLogin from "@/components/PrometeoLogin";
export default function Index() { return <PrometeoLogin />; }
