import dynamic from "next/dynamic";
import PrometeoAccessGate from "@/components/PrometeoAccessGate";
const Constructor=dynamic(()=>import("../components/chat/Constructor"),{ssr:false});
export default function ConstructorPage(){return <PrometeoAccessGate><Constructor /></PrometeoAccessGate>;}
