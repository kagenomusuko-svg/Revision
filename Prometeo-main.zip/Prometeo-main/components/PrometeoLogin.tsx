import { FormEvent, useState } from "react";
import { useRouter } from "next/router";
import { getSupabaseClient } from "../lib/supabaseClient";
import { checkPrometeoAccess } from "../lib/prometeoAccess";
export default function PrometeoLogin() {
  const router = useRouter();
  const [email,setEmail]=useState(""); const [password,setPassword]=useState("");
  const [busy,setBusy]=useState(false); const [message,setMessage]=useState("");
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setMessage("");
    try {
      const { error } = await getSupabaseClient().auth.signInWithPassword({ email, password });
      if (error) throw error;
      const access = await checkPrometeoAccess();
      if (access.status !== "authorized") {
        await getSupabaseClient().auth.signOut();
        if (access.status === "denied") throw new Error("Tu cuenta aún no tiene permiso para Prometeo. Solicita acceso a la administración.");
        throw new Error(access.message || "No se pudo validar el acceso.");
      }
      await router.replace("/constructor");
    } catch (error) { setMessage(error instanceof Error ? error.message : "No fue posible iniciar sesión."); }
    finally { setBusy(false); }
  }
  return <main className="login-page"><section className="login-card">
    <div className="login-eyebrow">HERRAMIENTA INSTITUCIONAL</div><h1>Ingreso a Prometeo</h1>
    <p>Calculador de Metrología causal del Centro Multidisciplinario Meriadock.</p>
    <form onSubmit={submit}>
      <label>Correo electrónico<input type="email" autoComplete="username" required value={email} onChange={e=>setEmail(e.target.value)} /></label>
      <label>Contraseña<input type="password" autoComplete="current-password" required value={password} onChange={e=>setPassword(e.target.value)} /></label>
      {message && <p role="alert" className="login-alert">{message}</p>}
      <button type="submit" disabled={busy}>{busy ? "Verificando…" : "Iniciar sesión"}</button>
    </form><p className="login-note">Usa tu cuenta de Meriadock Academy. El acceso a Prometeo se habilita por separado.</p>
  </section></main>;
}
