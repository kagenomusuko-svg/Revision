const SITE_URL = "https://www.meriadock.org.mx";
export default function InstitutionalFooter() {
  return <footer className="institutional-footer">
    <div className="footer-main">
      <div className="footer-brand">
        <a href={`${SITE_URL}/home`} aria-label="Ir al sitio principal de Centro Multidisciplinario Meriadock">
          <img src={`${SITE_URL}/ac_seal.png`} alt="Sello del Centro Multidisciplinario Meriadock"/>
        </a>
        <div>
          <div className="footer-org">Centro Multidisciplinario Meriadock</div>
          <div className="footer-org-sub">Formación y Asesoría A.C.</div>
          <div className="footer-motto">&quot;La fuerza interior nos impulsa, un pequeño apoyo de los demás nos bendice&quot;</div>
        </div>
      </div>
      <a className="footer-privacy" href={`${SITE_URL}/aviso-de-privacidad`}>Aviso de Privacidad</a>
    </div>
    <div className="footer-copyright"><div>© {new Date().getFullYear()} Centro Multidisciplinario Meriadock — Todos los derechos reservados.</div></div>
  </footer>;
}
