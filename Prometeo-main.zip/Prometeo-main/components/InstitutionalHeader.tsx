import { useEffect, useState } from "react";
import type { AuthChangeEvent, Session } from "@supabase/supabase-js";
import Link from "next/link";
import { useRouter } from "next/router";
import { getSupabaseClient } from "../lib/supabaseClient";

const SITE_URL = "https://www.meriadock.org.mx";
export default function InstitutionalHeader() {
  const router=useRouter();
  const [isAuthenticated,setIsAuthenticated]=useState(false);
  const [authChecked,setAuthChecked]=useState(false);
  useEffect(()=>{
    const supabase=getSupabaseClient();
    const loadSession=async()=>{const {data:{user}}=await supabase.auth.getUser();setIsAuthenticated(Boolean(user));setAuthChecked(true);};
    loadSession();
    const {data:{subscription}}=supabase.auth.onAuthStateChange((_event: AuthChangeEvent,session: Session | null)=>{setIsAuthenticated(Boolean(session?.user));setAuthChecked(true);});
    return ()=>subscription.unsubscribe();
  },[]);
  const handleLogout=async()=>{await getSupabaseClient().auth.signOut();setIsAuthenticated(false);router.replace("/");};
  return <header className="institutional-header">
    <div className="institutional-header-inner">
      <a href={`${SITE_URL}/home`} className="institutional-brand" aria-label="Centro Multidisciplinario Meriadock">
        <img src={`${SITE_URL}/ac_seal.png`} alt="Sello del Centro Multidisciplinario Meriadock"/>
        <span><strong>Centro Multidisciplinario Meriadock</strong><small>Formación y Asesoría A.C.</small></span>
      </a>
      {authChecked&&isAuthenticated
        ? <nav className="institutional-nav" aria-label="Navegación de Prometeo"><Link href="/constructor">Prometeo</Link></nav>
        : <div aria-hidden="true"/>}
      <div className="institutional-session">
        {!authChecked?<div className="session-placeholder" aria-hidden="true"/>
          :isAuthenticated?<button type="button" onClick={handleLogout}>Salir</button>
          :<Link href="/">Iniciar sesión</Link>}
      </div>
    </div>
  </header>;
}
