import { ReactNode, useEffect, useState } from "react";
import { useRouter } from "next/router";
import Link from "next/link";
import { checkPrometeoAccess } from "../lib/prometeoAccess";
import { getSupabaseClient } from "../lib/supabaseClient";
export default function PrometeoAccessGate({children}:{children:ReactNode}) {
  const router=useRouter(); const [allowed,setAllowed]=useState(false); const [message,setMessage]=useState("Verificando tu acceso…");
  useEffect(()=>{let alive=true;checkPrometeoAccess().then(async result=>{
    if(!alive)return;
    if(result.status==="authorized"){setAllowed(true);return;}
    if(result.status==="denied"){setMessage("Esta cuenta no tiene permiso para usar Prometeo.");return;}
    if(result.status==="error"){setMessage(result.message);return;}
    await getSupabaseClient().auth.signOut();router.replace("/");
  });return()=>{alive=false;};},[router]);
  if(!allowed)return <main className="login-page"><section className="login-card" role="status"><h1>Prometeo</h1><p>{message}</p><Link href="/">Volver al ingreso</Link></section></main>;
  return <>{children}</>;
}
