'use strict';
const {test}=require('node:test');
const a=require('node:assert/strict');
const {calcularSolicitud}=require('../dist-motor/entrada');
const {listarOperadoresEjecutables}=require('../dist-motor/operadores-taxonomicos');
const fixture=require('../auditoria/fixtures/diferencial.json');

test('OP24 calcula opacidad con R* y S',()=>{
 const q=structuredClone(fixture);q.medicionesSolicitadas=['rStar','s','opacidad'];
 for(const n of q.analisis.nodosActivos){n.s.confirmado=true;n.s.referencia='fixture-opacidad';}
 const r=calcularSolicitud(q),o=r.resultados.opacidad;
 a.equal(o.estado,'calculado');a.equal(o.auditoria.formula,'Opacidad(G)=Σ R*_i×S_i');a.ok(o.valor>=0);
});

test('OP25 calcula predictor sectorial con entradas y betas explícitos',()=>{
 const q=structuredClone(fixture);q.medicionesSolicitadas=['probabilidadSectorial'];
 q.insumos={probabilidadSectorial:{S_consejo:.4,IIC:.8,P_Anteros_CEO:.2,R_star_cultura_neta:.3,N_anios:5,betas:[-3.2,2.8,1.6,2.1,1.4]}};
 const o=calcularSolicitud(q).resultados.probabilidadSectorial;
 a.equal(o.estado,'calculado');a.ok(o.valor>0&&o.valor<1);a.match(o.auditoria.formula,/σ\(\(/);
});

test('OP32 calcula S_B, CI y Shapley exacto con v(S) completo',()=>{
 const q=structuredClone(fixture);q.medicionesSolicitadas=['shapleyDeportivo'];
 q.insumos={shapleyDeportivo:{jugadores:['a','b'],rStarB:[.6,.4],pVictoriaCon:[.7,.5],pVictoriaSin:[.4,.5],coaliciones:[{miembros:[],valor:0},{miembros:['a'],valor:.7},{miembros:['b'],valor:.5},{miembros:['a','b'],valor:.8}]}};
 const o=calcularSolicitud(q).resultados.shapleyDeportivo;
 a.equal(o.estado,'calculado');a.ok(Math.abs(o.valor.filas[0].S_B-.7)<1e-12);a.ok(Math.abs(o.valor.filas[0].CI-.18)<1e-12);a.equal(o.valor.shapley[0].id,'a');a.ok(Math.abs(o.valor.shapley[0].valor-.5)<1e-12);a.equal(o.valor.shapley[1].id,'b');a.ok(Math.abs(o.valor.shapley[1].valor-.3)<1e-12);
});

test('robustez informa propiedades del resultado calculado',()=>{
 const q=structuredClone(fixture);q.medicionesSolicitadas=['rStar','robustez'];
 const o=calcularSolicitud(q).resultados.robustez;
 a.equal(o.estado,'calculado');a.ok(['A','B','C','D','IND'].includes(o.valor.nivel));
});

test('el catálogo público coincide con el repertorio ejecutable',()=>{
 const ops=listarOperadoresEjecutables();
 a.equal(ops.length,23);
 a.ok(ops.every(o=>o.registro&&o.nombre&&o.formula&&o.inputs.length));
});
