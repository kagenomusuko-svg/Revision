'use strict';
const {test}=require('node:test');
const a=require('node:assert/strict');
const {disponibilidad,validarCoberturaOperadores,listarOperadoresEjecutables}=require('../dist-motor/operadores-taxonomicos');
const {REGISTRY}=require('../dist-motor/series');
const {calcularSolicitud}=require('../dist-motor/entrada');
const {generarHTML}=require('../dist-motor/expediente');
const fixture=require('../auditoria/fixtures/diferencial.json');

test('el catálogo contiene únicamente operadores ejecutables con contrato completo',()=>{
 a.equal(validarCoberturaOperadores(),true);
 a.equal(disponibilidad.length,23);
 for(const op of disponibilidad){
  a.ok(op.registro,op.id);
  a.ok(REGISTRY[op.registro],`${op.id} sin registro ${op.registro}`);
  a.ok(op.formula,op.id);
  a.ok(op.inputs.length,op.id);
  a.equal(Object.hasOwn(op,'estado'),false);
  a.equal(Object.hasOwn(op,'notaImplementacion'),false);
 }
 a.equal(listarOperadoresEjecutables().length,disponibilidad.length);
});

test('el expediente contiene el cálculo solicitado y omite mediciones no solicitadas',()=>{
 const q=structuredClone(fixture);q.medicionesSolicitadas=['rStar'];
 const r=calcularSolicitud(q),html=generarHTML(r);
 a.equal(r.auditoria.operadoresDisponibles,undefined);
 a.equal(r.snapshot.operadoresDisponibles,undefined);
 a.doesNotMatch(html,/no_solicitado/);
});

test('operadores avanzados conservan entradas explícitas y ausencia indeterminada',()=>{
 const q=structuredClone(fixture);q.medicionesSolicitadas=['indiceInversion','conversionVital','roiPrevencion','impactoCausal','brechaBeneficio'];
 q.insumos={indiceInversion:{disenadorId:'a',ejecutorId:'b',deltaDisenador:.1,deltaEjecutor:-.56},conversionVital:{monto:100,salarioReferencia:10,unidad:'MXN'},roiPrevencion:{danioTotal:50,costo:10,deltaP:.2,unidad:'MXN',baseDeltaP:'estudio externo'},comparacion:{referenciaAntes:'A',referenciaDespues:'B',baseComparabilidad:'misma muestra',valores:[{id:'a',rAntes:.5,rDespues:.4},{id:'b',rAntes:.5,rDespues:.6}]},brechaBeneficio:{unidad:'MXN',valores:[{id:'a',recibido:10,revertido:4},{id:'b',recibido:2,revertido:1}]}};
 const r=calcularSolicitud(q);
 a.equal(r.resultados.indiceInversion.estado,'calculado');a.equal(r.resultados.conversionVital.estado,'calculado');a.equal(r.resultados.roiPrevencion.estado,'calculado');a.equal(r.resultados.impactoCausal.estado,'calculado');a.equal(r.resultados.brechaBeneficio.estado,'calculado');
 delete q.insumos.roiPrevencion.deltaP;a.equal(calcularSolicitud(q).resultados.roiPrevencion.estado,'indeterminado');
});
