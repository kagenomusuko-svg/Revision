'use strict';
const {test}=require('node:test');
const a=require('node:assert/strict');
const {validarDeclarativo}=require('../taxonomia/schema');
const {listarProtocolos}=require('../taxonomia/protocolos');
const files=['dominios.v1.json','capitulos-03-20.v1.json','capitulos-21-40.v1.json','capitulos-41-60.v1.json','capitulos-61-78.v1.json'];
const protocolos=files.flatMap(f=>require('../taxonomia/datos/'+f));

test('la Taxonomía operativa cubre los 78 capítulos con referencias trazables',()=>{
 a.equal(protocolos.length,78);
 a.equal(new Set(protocolos.map(p=>p.id+'@'+p.version)).size,78);
 for(const p of protocolos){
  a.equal(validarDeclarativo(p).id,p.id);
  a.ok(p.sourceRef.repositorio);
  a.match(p.sourceRef.sha,/^[a-f0-9]{40}$/);
  a.ok(Array.isArray(p.componentesS));
  a.ok(Array.isArray(p.preguntas));
  a.ok(Array.isArray(p.rangos));
  a.ok(Array.isArray(p.estrategiasAlpha));
  a.equal(Object.hasOwn(p.sourceRef,'estado'),false);
 }
});

test('el registro carga todos los protocolos y sus universales operativos',()=>{
 const ps=listarProtocolos();
 for(const p of protocolos){
  const q=ps.find(x=>x.id===p.id&&x.version===p.version);
  a.ok(q,p.id);
  a.ok(q.componentesS.length,p.id);
  a.ok(q.requiereConfirmacionS,p.id);
  a.ok(q.reglasEfectivas.length>0,p.id);
 }
});
