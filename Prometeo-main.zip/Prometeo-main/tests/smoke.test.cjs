const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
test('acceso protegido con Supabase Auth y sin servicios externos innecesarios',()=>{
 const p=require('../package.json');
 assert.equal(p.dependencies['@supabase/supabase-js'],'2.112.3');
 assert.ok(!Object.keys(p.dependencies).some(k=>/anthropic|mammoth/.test(k)));
 assert.match(fs.readFileSync('pages/index.tsx','utf8'),/PrometeoLogin/);
 assert.match(fs.readFileSync('next.config.js','utf8'),/basePath:\s*["']\/tecnologia\/Prometeo["']/);
 for(const f of ['pages/login.tsx','pages/dashboard.tsx','pages/api/chat.js','utils/supabaseClient.js']) assert.ok(!fs.existsSync(f));
 assert.ok(fs.existsSync('pages/constructor.tsx'));
 for(const endpoint of ['calcular','expediente','narrativa','operadores','protocolos']) {
   assert.match(fs.readFileSync('pages/api/'+endpoint+'.js','utf8'),/requirePrometeoAccess/);
 }
 assert.doesNotMatch(fs.readFileSync('lib/server/requirePrometeoAccess.js','utf8'),/SERVICE_ROLE|service_role/i);
});
