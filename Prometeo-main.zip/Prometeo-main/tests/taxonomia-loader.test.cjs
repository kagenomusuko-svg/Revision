const {test}=require('node:test'),a=require('node:assert/strict');
const {resolverProtocolo,listarProtocolos}=require('../taxonomia/protocolos');
const {calcularSolicitud}=require('../dist-motor/entrada');
const {generarHTML}=require('../dist-motor/expediente');
const f=require('../auditoria/fixtures/diferencial.json');

test('overlay versionado hereda universales, conserva copia y rechaza dominio incorrecto',()=>{
 const p=resolverProtocolo('tax-cap01@1','penal_civil');
 a.equal(p.universales.length,4);
 a.equal(p.rangos.find(x=>x.nivel===2).min,.70);
 a.throws(()=>resolverProtocolo('tax-cap01@1','otro'),/incompatible/);
 p.universales[0].reglas[0].texto='mutado';
 a.notEqual(resolverProtocolo('tax-cap01@1','penal_civil').universales[0].reglas[0].texto,'mutado');
 a.equal(listarProtocolos().find(p=>p.id==='generico').version,'1');
});

test('el protocolo cambia la orientación sin alterar PF y S exige confirmación humana',()=>{
 const q=structuredClone(f),base=calcularSolicitud(q);
 q.analisis.taxonomiaVersion='tax-cap01@1';q.analisis.dominio='penal_civil';q.medicionesSolicitadas.push('s');
 q.analisis.nodosActivos.forEach(n=>n.s={componentes:[.4]});
 let r=calcularSolicitud(q);
 a.equal(r.resultados.s.estado,'indeterminado');
 a.ok(r.mensajes.some(x=>x.codigo==='ERR_S_SIN_CONFIRMACION'));
 q.analisis.nodosActivos.forEach(n=>n.s={componentes:[.4],confirmado:true,referencia:'discriminación humana'});
 r=calcularSolicitud(q);
 a.equal(r.resultados.s.valor[0].valor,.4);
 a.deepEqual(r.resultados.rStar.valor,base.resultados.rStar.valor);
 a.equal(r.snapshot.protocoloEfectivo.sourceRef.sha,'e7c7b06eebd56e412a8b27f3c58747af2d1e531c');
 a.match(generarHTML(r),/tax-cap01/);
});

test('el capítulo 2 aplica sus rangos numéricos en las tres familias',()=>{
 const p=resolverProtocolo('tax-cap02@1','laboral');
 a.equal(p.rangos[0].min,.76);
 a.ok(p.rangos.every(r=>Number.isFinite(r.min)&&Number.isFinite(r.max)));
 a.ok(p.rangos.every(r=>!Object.hasOwn(r,'estado')));
 for(const familia of ['imputacion_causal','compliance_causal','contabilidad_ontologica']){
  const q=structuredClone(f);q.analisis.taxonomiaVersion='tax-cap02@1';q.analisis.dominio='laboral';q.analisis.familia=familia;
  a.equal(calcularSolicitud(q).resultados.rStar.estado,'calculado');
 }
});
