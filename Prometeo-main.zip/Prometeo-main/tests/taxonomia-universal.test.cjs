const {test}=require('node:test'),a=require('node:assert/strict');
const s=require('../taxonomia/schema'),u=require('../taxonomia/universal');

test('schema taxonómico conserva procedencia, copia y unicidad de reglas',()=>{
 a.equal(u.protocolos.length,4);
 for(const p of u.protocolos){
  a.equal(s.validarDeclarativo(p).schemaVersion,'taxonomia/1');
  a.equal(Object.hasOwn(p.sourceRef,'estado'),false);
  if(p.reglas.length){
   const q=structuredClone(p);q.reglas[0].sourceRef.sha='main';a.throws(()=>s.validarDeclarativo(q),/sourceRef/);
   q.reglas[0].sourceRef.sha=p.reglas[0].sourceRef.sha;q.reglas.push(q.reglas[0]);a.throws(()=>s.validarDeclarativo(q),/duplicada/);
  }
 }
 const r=u.protocolos[2].reglas.find(r=>r.id==='u3.ds1');
 a.equal(s.confirmarSugerencia(r,{valor:.9}).estado,'indeterminado');
 a.equal(s.confirmarSugerencia({...r,rango:r.valor},{valor:.9,confirmado:true,referencia:'discriminación humana'}).valor,.9);
});

test('U1 conserva discriminación, confirmación e indeterminación explícitas',()=>{
 a.equal(u.orientarHijo({}).estado,'INDETERMINADO');
 a.equal(u.orientarHijo({energia:'no',ausencia:'generalizada',busquedaAusente:'no'}).estado,'REQUIERE_ECO');
 a.equal(u.orientarHijo({energia:'si',direccion:'reactiva',desproporcion:'si',patronSostenido:'si'}).hijo,'fobos');
 a.equal(u.orientarHijo({energia:'si',direccion:'reactiva',desproporcion:'si'}).estado,'HIPOTESIS');
 a.equal(u.orientarHijo({energia:'si',direccion:'proactiva',friccion:'no',orientacion:'nuevo'}).estado,'HIPOTESIS');
});

test('U3 calcula intervalo ponderado y respeta límites situacionales',()=>{
 const p={fobos:.15,anteros:.55,eros:.2,deimos:.05,potos:.05,harmonia:0},c={confirmado:true,justificaciones:{fobos:'a',anteros:'b',eros:'c',deimos:'d',potos:'e'}};
 a.equal(u.intervaloRutaA(p,{}).estado,'indeterminado');
 const r=u.intervaloRutaA(p,c);a.ok(Math.abs(r.rango[0]-.274)<1e-12);a.ok(Math.abs(r.rango[1]-.5105)<1e-12);a.equal(r.confirmado,false);
 a.equal(u.intervaloRutaA({...p,harmonia:.05,potos:0},c).estado,'error');
 a.equal(u.intervaloRutaA(p,{...c,noDisponible:true}).estado,'error');
});

test('intersección de rangos conserva contradicción explícita y cero declarado',()=>{
 a.deepEqual(u.combinarRangos([[.55,.75],[.4,.6]]).rango,[.55,.6]);
 a.equal(u.combinarRangos([[.75,.95],[.4,.6]]).estado,'contradiccion');
 a.equal(u.combinarRangos([]).estado,'indeterminado');
 a.deepEqual(u.combinarRangos([[0,0]]).rango,[0,0]);
});

test('confirmación numérica rechaza truthy, fuera de rango y presencia incompatible',()=>{
 const r=u.protocolos[2].reglas.find(r=>r.id==='u3.ds1');
 a.equal(s.confirmarSugerencia(r,{valor:.9,confirmado:'false',referencia:'x'}).estado,'indeterminado');
 a.equal(s.confirmarSugerencia({...r,rango:r.valor},{valor:.1,confirmado:true,referencia:'x'}).estado,'error');
 const p={fobos:1,deimos:0,anteros:0,eros:0,potos:0,harmonia:0};
 a.equal(u.validarDistribucion(p,{confirmado:true,presencia:true,noDisponible:true,justificaciones:{fobos:'x'}}).estado,'error');
});

test('schema formal define contratos y procedencia sin estados de credibilidad',()=>{
 const schema=require('../taxonomia/schema.v1.json');
 a.ok(schema.required.includes('sourceRef'));
 a.ok(schema.$defs.regla.required.includes('condiciones'));
 a.equal(Object.hasOwn(schema.$defs,'estado'),false);
 a.equal(Object.hasOwn(schema.$defs.sourceRef.properties,'estado'),false);
});
