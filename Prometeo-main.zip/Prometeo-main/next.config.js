/** @type {import('next').NextConfig} */
module.exports = { reactStrictMode: true, basePath: "/tecnologia/Prometeo" };
