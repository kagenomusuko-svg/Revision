'use strict';
const {sumaFinita, exigirFinitud}=require('./numerica');

const ausente=x=>x===null||x===undefined;
const indeterminado=motivo=>({estado:'indeterminado',valor:null,motivo});
function finitos(xs){return Array.isArray(xs)&&xs.every(Number.isFinite);}

// OP24 — Opacidad estructural.  La fuente define la magnitud sobre el
// resultado R* y la sustituibilidad S de los nodos visibles; no requiere una
// criterios externos ni inventa umbral de alerta.
function opacidad(c){
  const r=c.resultados.rStar?.valor;
  const s=c.resultados.s?.valor;
  if(!Array.isArray(r)||!Array.isArray(s)||r.length!==s.length||!r.length)return indeterminado('Opacidad requiere R* y S para el mismo universo de nodos');
  const filas=r.map((x,i)=>({id:x.id||c.nodos?.[i]?.id||String(i),rStar:typeof x==='number'?x:x.valor,s:typeof s[i]==='number'?s[i]:s[i]?.valor}));
  if(filas.some(x=>ausente(x.rStar)||ausente(x.s)))return indeterminado('Opacidad requiere R* y S definidos para todos los nodos');
  if(filas.some(x=>![x.rStar,x.s].every(Number.isFinite)))throw Error('Opacidad requiere valores finitos');
  return {estado:'calculado',valor:sumaFinita(filas.map(x=>x.rStar*x.s)),motivo:null,filas,
    auditoria:{formula:'Opacidad(G)=Σ R*_i×S_i',fuente:'El cálculo de la responsabilidad, cap. 2 §6.2',alcance:'magnitud estructural del resultado; no activa umbral ni juicio de legitimidad'}};
}

// OP25 — Predictor logístico sectorial. Todos los insumos y coeficientes son
// declarados por el analista; el motor no sustituye ni infiere ninguno.
function probabilidadSectorial(input){
  if(!input||!finitos([input.S_consejo,input.IIC,input.P_Anteros_CEO,input.R_star_cultura_neta,input.N_anios])||!Array.isArray(input.betas)||input.betas.length!==5||!finitos(input.betas))return indeterminado('Probabilidad sectorial requiere S_consejo, IIC, P_Anteros_CEO, R*_cultura_neta, horizonte y cinco coeficientes declarados');
  const [b0,b1,b2,b3,b4]=input.betas;
  if([input.S_consejo,input.IIC,input.P_Anteros_CEO,input.R_star_cultura_neta].some(x=>x<0||x>1)||input.N_anios<=0)throw Error('Entradas de probabilidad sectorial fuera de dominio');
  const logit=b0+b1*input.S_consejo+b2*(1-input.IIC)+b3*input.P_Anteros_CEO+b4*input.R_star_cultura_neta;
  const logitN=logit*(input.N_anios/5);const p=1/(1+Math.exp(-logitN));exigirFinitud(p);
  const nivel=p>.70?'MUY_ALTO':p>.45?'ALTO':p>.25?'MODERADO':'BAJO';
  return {estado:'calculado',valor:p,motivo:null,logit,logitHorizonte:logitN,nivelRiesgo:nivel,insumos:structuredClone(input),auditoria:{formula:'σ((β₀+β₁S_consejo+β₂(1−IIC)+β₃P_Anteros+β₄R*_cultura_neta)×N/5)',fuente:'El cálculo de la responsabilidad, cap. 11 §5.5',alcance:'probabilidad sectorial del resultado; coeficientes e inputs pertenecen al análisis declarado'}};
}

// OP32 — S_B/CI y, cuando existe el juego completo, Shapley deportivo.
function shapleyDeportivo(input){
  if(!input||!Array.isArray(input.jugadores)||!Array.isArray(input.rStarB)||!Array.isArray(input.pVictoriaCon)||!Array.isArray(input.pVictoriaSin))return indeterminado('Shapley deportivo requiere jugadores, R*_B, P(victoria|con) y P(victoria|sin)');
  const n=input.jugadores.length;if(!n||[input.rStarB,input.pVictoriaCon,input.pVictoriaSin].some(x=>x.length!==n)||input.jugadores.some(x=>typeof x!=='string'||!x))return indeterminado('Vectores deportivos incompletos o IDs inválidos');
  if(![input.rStarB,input.pVictoriaCon,input.pVictoriaSin].every(finitos))return indeterminado('Vectores deportivos contienen datos no finitos');
  if(input.rStarB.some(x=>x<0||x>1)||input.pVictoriaCon.some(x=>x<0||x>1)||input.pVictoriaSin.some(x=>x<0||x>1))throw Error('Vectores deportivos fuera de [0,1]');
  const filas=input.jugadores.map((id,i)=>({id,R_star_B:input.rStarB[i],S_B:1-Math.abs(input.pVictoriaCon[i]-input.pVictoriaSin[i]),CI:input.rStarB[i]*(Math.abs(input.pVictoriaCon[i]-input.pVictoriaSin[i]))}));
  let shapley=null;
  if(Array.isArray(input.coaliciones)){
    const ids=input.jugadores, total=2**n, byMask=new Map();
    for(const c of input.coaliciones){if(!Array.isArray(c.miembros)||c.miembros.some(id=>!ids.includes(id))||new Set(c.miembros).size!==c.miembros.length||!Number.isFinite(c.valor))throw Error('Coalición deportiva inválida');const mask=c.miembros.reduce((m,id)=>m+2**ids.indexOf(id),0);if(byMask.has(mask))throw Error('Coalición deportiva duplicada');byMask.set(mask,c.valor);}
    if(byMask.size!==total||byMask.get(0)!==0)return indeterminado('Juego deportivo incompleto o v(vacío) no declarado');
    const fact=n=>{let x=1;for(let i=2;i<=n;i++)x*=i;return x;};
    shapley=ids.map((id,i)=>{let value=0;for(let mask=0;mask<total;mask++)if(!(mask&(2**i))){let k=0,m=mask;while(m){k+=m%2;m=Math.floor(m/2);}value+=(byMask.get(mask+2**i)-byMask.get(mask))*fact(k)*fact(n-k-1)/fact(n);}return {id,valor:value};});
  }
  return {estado:'calculado',valor:{filas,shapley},motivo:null,auditoria:{formula:'S_B=1−|P(con)−P(sin)|; CI=R*_B×(1−S_B); φ_B=Shapley(v)',fuente:'El cálculo de la responsabilidad, cap. 17 §§3.3, 6.2',alcance:'contribución deportiva del resultado; no estima datos ausentes ni suplencias no declaradas'}};
}
module.exports={opacidad,probabilidadSectorial,shapleyDeportivo};
