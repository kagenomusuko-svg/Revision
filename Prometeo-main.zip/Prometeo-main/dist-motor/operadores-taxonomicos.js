'use strict';
const RAW=require('./operadores-taxonomicos.json');
const disponibilidad=RAW.map(x=>structuredClone(x));
const porId=new Map(disponibilidad.map(x=>[x.id,x]));
function listarOperadoresTaxonomicos(){return disponibilidad.map(x=>structuredClone(x));}
function listarOperadoresEjecutables(){return disponibilidad.map(x=>({id:x.id,registro:x.registro,nombre:x.nombre,formula:x.formula,inputs:structuredClone(x.inputs||[])}));}
function obtenerOperadorTaxonomico(id){const x=porId.get(id);return x?structuredClone(x):null;}
function validarCoberturaOperadores(){
 if(!disponibilidad.length)throw Error('Catálogo de operadores vacío');
 if(new Set(disponibilidad.map(x=>x.id)).size!==disponibilidad.length)throw Error('IDs OP repetidos');
 if(new Set(disponibilidad.map(x=>x.registro)).size!==disponibilidad.length)throw Error('Registros de operador repetidos');
 for(const op of disponibilidad)if(!op.registro||!op.formula||!Array.isArray(op.inputs)||!op.inputs.length)throw Error('Operador sin contrato ejecutable: '+op.id);
 return true;
}
validarCoberturaOperadores();
module.exports={disponibilidad,listarOperadoresTaxonomicos,listarOperadoresEjecutables,obtenerOperadorTaxonomico,validarCoberturaOperadores};
