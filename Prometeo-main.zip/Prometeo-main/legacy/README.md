# Archivo histórico inactivo — AU-16

`escalas.js` conserva parametrizaciones ilustrativas y defaults del prototipo; `espacio.js` conserva álgebra vectorial L2/coseno. Ninguno pertenece al motor vigente ni se importa desde `dist-motor`, `components` o `pages`.

La ruta de ejemplo `pages/api/hello.ts` fue eliminada; no interviene en el calculador. El historial Git conserva su contenido.

`fraude_annona.js` conserva una implementación histórica del producto `R*(1-alpha)*(1-IIC)`. El motor vigente utiliza únicamente los contratos activos registrados.
